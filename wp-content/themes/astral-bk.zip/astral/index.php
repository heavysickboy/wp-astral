<?php 

get_header();
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12 mb-3">
            <?php the_content(); ?>
        </div>
    </div>
</div>
<?php
get_footer();
?>