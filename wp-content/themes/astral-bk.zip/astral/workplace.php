<?php
//Template Name: workplace
/*
Template Post Type: careers
*/

get_header();
?>
    
<div class="pageWrapper" id="sticky-anchor">
  <!-- banner starts -->
  <section  class="innerBanner position-relative">
    <img src="<?php the_cfc_field( 'inner_banner','inner_banner_pic'); ?>" class="w-100">
    <div class="container d-flex align-items-md-center align-items-end">
      <h1><?php the_cfc_field( 'inner_banner','inner_page_title'); ?></h1>
    </div>
  </section>
  <!-- banner ends -->

  <section class="py-5 careerWrap">

    <div class="container py-md-4 position-relative">
      
      <img src="images/bgblackDrops.png" class="ContDropsTop">

      <div class="row position-relative gx-5">
        <div class="col-lg-9 ps-xxl-5 mb-5 mb-lg-0">

          <p class="mb-5"><?php the_cfc_field( 'workplace_content','work_brief'); ?></p>


          <h1 class="mb-5"><?php the_cfc_field( 'workplace_content','work_reason_title'); ?></h1>




          <div class=" w-100 overflow-hidden mb-5">
            <div class="careerSwiper swiper">
            <div class="swiper-wrapper">

            <?php 

$i = 1;

foreach( get_cfc_meta( 'workplace' ) as $key => $value ){ ?> 

  
              <div class="swiper-slide">
                
                  <div class="row g-0 newArrivalItem h-100 text-white">
                    <div class="col-lg-6 col-md-6 position-relative overflow-hidden">
                      <img src="<?php the_cfc_field( 'workplace','workplace_image', false, $key ); ?>" class="workImg">
                    </div>
                    <div class="col-lg-6 col-md-6 workDetails" style="background:url(<?php print(get_template_directory_uri()); ?>/images/work_1_film.jpg) no-repeat;">
                      
                      <div class="workBox">
                        
                        <h2 class="workPlaceName mb-4"> <?php the_cfc_field( 'workplace','workplace_title', false, $key ); ?></h2>
                        <p class="mb-4"><?php the_cfc_field( 'workplace','workplace_para', false, $key ); ?></p>
                        
                      </div>

                      
                    </div>
                  </div>
                
              </div>

              
<?php 

$i++;

}  ?>
              
  
            </div>
           

            <div class="swiper-button-prev"></div>
       <div class="swiper-button-next"></div>
          </div>
        </div>




          <div class="weLook position-relative">
              <img src="<?php the_cfc_field( 'workplace_look_forword','forword_image'); ?>" class="w-100">
              <div class="weLookText">
                <div class="d-flex mb-4">
                  <div class="flex-shrink-0 me-3"><img src="<?php the_cfc_field( 'workplace_look_forword','forword_icon'); ?>"></div>
                  <div class="flex-grow-1"><?php the_cfc_field( 'workplace_look_forword','forword_text'); ?></div>
                </div>
              </div>
          </div>
          


        </div>
        <div class="col-lg-3 order-lg-first">

          <div class="d-lg-none mb-3 pt-3 border-top border-secondary"><strong>Related Links -</strong></div>
          
          <ul class="sideNavig">
            <li class="active"><a href="<?php site_url(); ?>/careers/workplace/">Workplace</a></li>
            <li><a href="<?php site_url(); ?>/careers/current-opening/">Current Openings</a></li>
          </ul>
          
        </div>
      </div>
    </div>

  </section>


</div>

    <?php
get_footer();
?>