<?php
//Template Name: aboutus
get_header();
?>    
<div class="pageWrapper" id="sticky-anchor">
  <!-- banner starts -->
  <section  class="innerBanner position-relative">
    <img src="<?php the_cfc_field( 'inner_banner','inner_banner_pic'); ?>" class="w-100">
    <div class="container d-flex align-items-md-center align-items-end">
      <h1><?php the_cfc_field( 'inner_banner','inner_page_title'); ?></h1>
    </div>
  </section>
  <!-- banner ends -->

  <!-- About Section -->
  <section>
    <div class="heading-wrapper py-5">
      <div class="heading">
          <h2 class="text-center"><?php the_cfc_field( 'about_detail','about_title'); ?></h2>
          <p class="text-center"><?php the_cfc_field( 'about_detail','about_para'); ?></p>
      </div>
    </div>

      <div class="img-text-wrapper position-relative">
          <img class="img-fluid" src="<?php the_cfc_field( 'about_legacy','legacy_image'); ?>" alt="">
          <div class="content position-absolute px-5 h-100">
              <div class="d-flex h-100 ">
                  <div class="m-auto">
                      <h3 class="text-white"><?php the_cfc_field( 'about_legacy','legacy_title'); ?></h3>
                      <p class="text-white"><?php the_cfc_field( 'about_legacy','legacy_para'); ?></p>
                  </div>
              </div>
          </div>
      </div>

      <div class="heading-wrapper py-5">
        <div class="heading">
          <h2 class="text-center"><?php the_cfc_field( 'philosophy_detail','philosophy_title'); ?></h2>
          <p class="text-center"><?php the_cfc_field( 'philosophy_detail','philosophy_para'); ?></p>
      </div>
      </div>
      

      <div class="img-text-wrapper position-relative">
          <img class="img-fluid" src="<?php the_cfc_field( 'about_innovation','innovation_image'); ?>" alt="">
          <div class="content position-absolute px-5 h-100">
              <div class="d-flex h-100 ">
                  <div class="m-auto">
                      <h3 class="text-white"><?php the_cfc_field( 'about_innovation','innovation_title'); ?></h3>
                      <p class="text-white"><?php the_cfc_field( 'about_innovation','innovation_para'); ?></p>
                  </div>
              </div>
          </div>
      </div>

  </section>

</div>
 <?php
get_footer();
?>